# 06 - Single Article Page 

## Constraints
 Change the title
 Create a article with several items inside
 - h2 and h4 tags for headings
 - p tag for texts
 - img tag for the photo
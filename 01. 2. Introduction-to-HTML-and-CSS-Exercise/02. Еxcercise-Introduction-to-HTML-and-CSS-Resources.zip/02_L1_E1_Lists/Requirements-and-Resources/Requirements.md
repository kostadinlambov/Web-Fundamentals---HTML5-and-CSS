# 02 - Lists

## Constraints
 Change the title
 Add section with two articles inside (for each list)
 Use <ul> for unordered list
	- Add four list items
 Use <ol reversed> for ordered reversed list
	- Add three list items
# 05 - Checkout Table

## Constraints
 Change the title
 Use <span>checked</span> for checked items
# 04 - Simple Data Table

## Constraints
 Change the title
 Use table, thead, and tbody tags
# 06. Photo Gallery - Flexbox

## Tasks
* Create an **"index.html"** file with title - **"Photo Gallery - Flexbox"**

## Constraints
* Add section with class **gallery** *(section.gallery)*
	* Change the **display** property to **flex**
	* Add **unordered list** with **list items** and **images** inside
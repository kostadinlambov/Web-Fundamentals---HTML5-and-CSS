# 07. Input Addon - Flexbox

## Tasks
* Create an **"index.html"** file with title - **"Input Addon - Flexbox"**
* Import **Font Awesome** in the CSS file and add the **icons** from there

## Constraints
* Create a **form** with **input** fields with different types inside
	* Remove the border of the each input field except the one of **submit** type
# 03. Photo Gallery - Inline Block

## Tasks
 * Create an **"index.html"** file with title - **"Photo Gallery - Inline Block"**
 * Use the images provided in the **resources** folder
 * Grab the background color with **color picker** and set it in [RGB model](https://www.rgbtohex.net/hextorgb/)

## Constraints
* Create **unordered list** with class **gallery** *(ul.gallery)*
	* Add **list items** with images inside
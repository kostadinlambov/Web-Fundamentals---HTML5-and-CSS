# 04. Buttons CSS

## Tasks
* Create an **"index.html"** file with title - **"Buttons CSS"**
* Take a look at **hover effects** in the screenshots
* Take the colors with **color picker** from the screenshots

## Constraints
* Change the **cursor** property to [pointer](https://www.w3schools.com/cssref/pr_class_cursor.asp)
* Change the **outline** property to [none](https://www.w3schools.com/Css/css_outline.asp)
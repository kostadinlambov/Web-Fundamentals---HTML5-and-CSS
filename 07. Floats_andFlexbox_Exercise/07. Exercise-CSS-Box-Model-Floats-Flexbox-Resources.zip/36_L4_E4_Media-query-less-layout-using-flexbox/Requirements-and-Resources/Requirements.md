# 08. Media Query Less Layout Using Flexbox

## Tasks
* Create an **"index.html"** file with title - **"Media Query Less Layout Using Flexbox"**


## Constraints
* Create a HTML [layout](https://www.w3schools.com/html/html_layout.asp) using semantic elements